--------------------------------------------------------------------------------------------------------------
-- McSA - 2012 MilchschniTTe - a.k.a MrMilchprodukT @ MTA:SA -------------------------------------------------
--------------------------------------------------------------------------------------------------------------




	McSA is... Minecraft in San Andreas ;)
	--------------------------------------

	Controls: ALT         = Enable the Edit-Mode to place and destroy blocks
		  LMB         = When in Edit-Mode -> Place selected block
		  RMB         = When in Edit-Mode -> Destroy selected block
		  MMB         = When in Edit-Mode -> Automaticly set your currently selected block to the block you�re pointing at
		  Mouse Wheel = When in Edit-Mode -> Switch between your blocks

	Commands: /mc_setblock [ID] 	= Set your currently selected block
		  /mc_protect	 	= Protect your own blocks from being destroyed :>
		  /mc_op		= [ADMIN-ONLY] Toggle the Protection-Override -> Allows you to destroy protected Blocks
		  /mc_stats		= [ENGINE] View Statistics
		  /mc_reloadblocks	= [ENGINE] Reload Block .dff .col. txd
		  /mc_creeper		= [EXPERIMENTAL][ADMIN-ONLY] Spawn a creeper :>

	Please dont edit anything where�s my name in this resource ;) ~Keep teh krediTs~